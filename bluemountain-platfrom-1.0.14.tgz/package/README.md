🚀 Platform SDK

A high-performance, enterprise-grade Node.js SDK for building distributed microservices using Azure Service Bus, HTTP, and ETCD.
✨ Key Features

    Distributed Request-Response: Sync communication over ASB using Session-based routing.

    Competing Consumers: Automated load balancing for incoming requests across multiple pods.

    Dynamic Config: Real-time configuration management via ETCD.

    Observability: Full OpenTelemetry integration with context propagation across transports.

    Smart Timeouts: Distributed timeout management using ASB Scheduled Messages.

📦 Installation
Bash

npm install @your-org/platform-sdk

🧠 Architecture Overview

The SDK bridges the gap between asynchronous messaging and synchronous developer experience. It uses Azure Service Bus Sessions to ensure that a response message finds the exact pod that sent the original request, even when running in a multi-pod cluster.
⚙️ Basic Usage
1️⃣ Define your Routes

Routes map incoming ASB operations to specific handler functions.
TypeScript

// routes.ts
export const routes = [
  {
    operation: 'PROCESS_PAYMENT',
    handle: async (payload) => {
        // Your business logic
        return { success: true };
    }
  }
];

2️⃣ Initialize the Platform

Create the instance and initialize it at your application's entry point.
TypeScript

// platform.ts
import { Platform } from "@your-org/platform-sdk";
import { routes } from "./routes";

export const platform = new Platform(
  {
    clientId: process.env.CLIENT_ID!,
    brokers: [], // Legacy Kafka field, kept for compatibility
  },
  process.env.SERVICE_NAME!
);

// index.ts
async function bootstrap() {
  await platform.init(routes);
  console.log("🚀 Platform is ready");
}

bootstrap();

🛠️ Communication Patterns
Synchronous Call (Request-Response)

Used when you need a result back from another service. Under the hood, this uses ASB Sessions and Correlation IDs.
TypeScript

const result = await platform.serviceBusSync({
  target: "payment-service",
  operation: "VERIFY_FUNDS",
  payload: { amount: 100 },
  mode: "SERVICEBUS"
});

Forward (Fire-and-Forget)

Used for notifications or when you don't need an immediate response.
TypeScript

await platform.forward({
  target: "notification-service",
  operation: "SEND_EMAIL",
  payload: { to: "user@example.com" },
  mode: "SERVICEBUS" // or "HTTP"
});

🔍 Observability & Tracing

The SDK comes with a @Traceable decorator to automatically link spans across HTTP and Service Bus boundaries.
TypeScript

import { Traceable } from "@your-org/platform-sdk";

class PaymentHandler {
  @Traceable("ProcessPayment")
  async handle(message) {
    // This will automatically extract the trace context from ASB applicationProperties
  }
}

⚙️ Environment Configuration

Ensure your environment provides the following keys for the SDK to function:
Variable	Description
ASB_CONNECTION_STRING	Azure Service Bus connection string (requires Manage claims for auto-sub creation).
ETCD_ENDPOINT	URL for your ETCD configuration store.
SERVICE_NAME	Unique name of your service (used for session mapping).
🛑 Graceful Shutdown

The SDK automatically handles SIGTERM. It ensures:

    Session Locks are released: Explicitly closes session receivers so the next pod can take over immediately.

    Senders are drained: Closes all AMQP links to prevent message loss.

    Telemetry Flush: Ensures final spans are sent to your collector.

📌 Best Practices

    One Instance: Always export a single instance of Platform to reuse connection pools.

    Fail Fast: The SDK validates target configurations from ETCD before sending messages.

    TTL & Cleanup: The SDK automatically creates subscriptions with a 10-minute Auto-Delete on Idle and a 1-minute Message TTL to keep your Azure namespace clean.

Workflow details.
create table if not exists platform."workflows" (
    workflow_id text primary key,
    workflow_type text not null,
    current_step text null,
    status text not null,
    context jsonb not null default '{}'::jsonb,
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now(),
    locked_by text null,
    lock_expires_at timestamptz null
);


create index if not exists idx_workflows_status_created_at
    on platform."workflows" (status, created_at);

create index if not exists idx_workflows_lock_expires_at
    on platform."workflows" (lock_expires_at);




📄 License

MIT